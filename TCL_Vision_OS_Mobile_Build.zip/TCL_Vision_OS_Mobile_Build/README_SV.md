# TCL Vision OS – mobilbyggbar version

Projektet är ett första launcher-prototype för TCL 43P615. APK byggs i GitHub Actions i molnet; ingen Windows-dator behövs.

## Bygg från iPhone
1. Hämta ZIP-filen och packa upp den i appen Filer.
2. Skapa ett privat eller offentligt repository på github.com i Safari.
3. Ladda upp innehållet i den uppackade projektmappen till repositoryts rot (inklusive den dolda mappen `.github/workflows`).
4. Öppna fliken Actions i repositoryt och välj `Build TCL Vision OS APK`.
5. Tryck `Run workflow`. Vänta tills körningen blir grön.
6. Öppna körningen och hämta artefakten `TCL-Vision-OS-APK`. Där ligger `app-debug.apk`.

Om GitHub på mobilen inte visar uppladdning av mappar: skapa filerna via webbgränssnittet eller använd GitHubs uppladdningsvy från Safari med skrivbordsvy. Se till att `.github/workflows/build-apk.yml` följer med; annars startar inte byggjobbet automatiskt.

## Installera på TV:n
En iPhone kan normalt inte installera en Android-APK direkt på TV:n. Du behöver föra över APK:n med USB-minne, eller använda en Android-telefon/ADB-kompatibel metod. På TV:n kan du behöva aktivera installation från okända källor för filhanteraren du använder.

Första versionen är ett testbygge. Behåll original-launchern och välj TCL Vision OS som hemskärm först efter att du testat att appar och fjärrkontroll fungerar. Byggfilen är en debug-APK och inte en publicerad/signad release.
