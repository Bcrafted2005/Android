package se.tclvisionos.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var clock: TextView
    private lateinit var appGrid: GridLayout
    private val blue = Color.rgb(65, 155, 255)
    private val white = Color.WHITE
    private val muted = Color.rgb(170, 190, 215)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        buildScreen()
        loadApps()
        updateClock()
    }

    private fun bg(color: Int, stroke: Int = Color.TRANSPARENT): GradientDrawable =
        GradientDrawable().apply {
            cornerRadius = 22f
            setColor(color)
            if (stroke != Color.TRANSPARENT) setStroke(3, stroke)
        }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(46, 30, 46, 28)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(7, 13, 28), Color.rgb(10, 25, 49), Color.rgb(5, 9, 20))
            )
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "TCL  /  VISION OS"
            textSize = 17f
            letterSpacing = 0.16f
            setTextColor(blue)
            typeface = Typeface.DEFAULT_BOLD
        }
        clock = TextView(this).apply {
            textSize = 17f
            setTextColor(muted)
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        top.addView(brand, LinearLayout.LayoutParams(0, 48, 1f))
        top.addView(clock, LinearLayout.LayoutParams(360, 48))
        page.addView(top)

        page.addView(TextView(this).apply {
            text = "Välkommen hem."
            textSize = 34f
            setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, 26, 0, 4)
        })
        page.addView(TextView(this).apply {
            text = "Dina appar, samlade på ett ställe"
            textSize = 16f
            setTextColor(muted)
            setPadding(0, 0, 0, 20)
        })
        page.addView(TextView(this).apply {
            text = "APPAR"
            textSize = 13f
            letterSpacing = 0.18f
            setTextColor(blue)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 10, 0, 12)
        })

        val scroll = ScrollView(this).apply { isFillViewport = true }
        appGrid = GridLayout(this).apply {
            columnCount = 5
            useDefaultMargins = false
            alignmentMode = GridLayout.ALIGN_BOUNDS
        }
        scroll.addView(appGrid)
        page.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 16, 0, 0)
        }
        bottom.addView(TextView(this).apply {
            text = "▲ ▼ ◀ ▶  Navigera     OK  Öppna"
            textSize = 13f
            setTextColor(muted)
        }, LinearLayout.LayoutParams(0, 54, 1f))
        bottom.addView(Button(this).apply {
            text = "Uppdatera appar"
            isAllCaps = false
            setTextColor(white)
            background = bg(Color.rgb(22, 49, 83), blue)
            setOnClickListener { loadApps() }
        }, LinearLayout.LayoutParams(220, 54))
        page.addView(bottom)
        setContentView(page)
    }

    private fun loadApps() {
        appGrid.removeAllViews()
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val leanbackIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val activities = (packageManager.queryIntentActivities(launcherIntent, 0) +
            packageManager.queryIntentActivities(leanbackIntent, 0))
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }

        for (info in activities) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isFocusable = true
                isFocusableInTouchMode = true
                background = bg(Color.rgb(15, 31, 54))
                setPadding(8, 14, 8, 12)
                setOnFocusChangeListener { v, focused ->
                    v.background = bg(
                        if (focused) Color.rgb(27, 59, 96) else Color.rgb(15, 31, 54),
                        if (focused) blue else Color.TRANSPARENT
                    )
                }
                setOnClickListener {
                    val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                    if (launch != null) startActivity(launch)
                }
            }
            item.addView(ImageView(this).apply {
                setImageDrawable(info.loadIcon(packageManager))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, LinearLayout.LayoutParams(64, 64))
            item.addView(TextView(this).apply {
                text = info.loadLabel(packageManager).toString()
                textSize = 13f
                setTextColor(white)
                gravity = Gravity.CENTER
                maxLines = 2
                setPadding(0, 10, 0, 0)
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 42))
            val lp = GridLayout.LayoutParams().apply {
                width = 0
                height = 138
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(7, 7, 7, 7)
            }
            appGrid.addView(item, lp)
        }
        if (activities.isEmpty()) {
            appGrid.addView(TextView(this).apply {
                text = "Inga appar hittades ännu."
                setTextColor(white)
                textSize = 18f
            })
        }
        appGrid.getChildAt(0)?.requestFocus()
    }

    private fun updateClock() {
        clock.text = SimpleDateFormat("EEEE d MMMM    HH:mm", Locale("sv", "SE")).format(Date())
        handler.postDelayed({ updateClock() }, 30_000)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
